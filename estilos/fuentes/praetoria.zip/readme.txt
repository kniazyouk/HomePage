OTF: Praetoria
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Praetoria is a serif titling font that was loosly modeled after the Roman square capitals used in ancient Rome. Some of the lowercase letters are ficticious variations of their uppercase counterparts. A few, however, such as the b and m were plucked from Russian and Greek alphabets respectively.
This display font is designed for games, movie posters, and book covers. You may use the uppercase letters exclusively but it is highly discouraged to do the same with the lowercase. It's recommended to simply use these sparingly as a compliment to uppercase. Basic Latin, kerning, numbers, 
and very limited punctuation are included in the demo version. 

Complete regular version is available with purchase of commercial license or $25 payment via PayPal. Please note that this $25 is for PERSONAL use only and does not constitute a commercial license.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info and terms. I also design custom 
fonts for companies, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

Thank you for your support!

visit www.sharkshock.net for more and take a bite out of BORING design!

tags: display, font, typeface, publishing, logo, title, book, cover, Rome, title, titling, square, antiquity, war, Greek,  Roman, diacritics, French, Polish, Sharkshock, German, Portuguese, European, emperor, Cassius, Caesar, Cyrillic, Russian, cut, sharp, irregular, fake, faux, capitals, caps, serif



